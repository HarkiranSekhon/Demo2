package com.example.harkirankaur.myproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class forgetPassword extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget_password);
    }
}
